<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category\Category;
use App\Models\Design\Design;
use DB;
use Illuminate\Http\Request;
use Illuminate\View\View;


/**
 * Class PageController.
 */
class PageController extends Controller
{
    /**
     * @return View
     */
    public function index()
    {
        return view('frontend.contact');
    }

    /**
     * @return View
     */
    public function trands(): View
    {
        return view('frontend.page.trands');
    }

    /**
     * @return View
     */
    public function designService(): View
    {
        return view('frontend.page.design_service');
    }

    /**
     * @return View
     */
    public function about(): View
    {
        return view('frontend..page.about');
    }

    /**
     * @return View
     */
    public function moodBoard(Request $request): View

    {
        $data['categories'] = Category::all();

        $data['detail'] = false;
        if ($request->input('detail')) {
            $cat_id = DB::table('category')
                ->where('category.slug', $request->input('detail'))->value('id');
            $data['detail'] = DB::table('design')
                ->where('design.category', $cat_id)->first();


            $data['recent_projects'] = Design::orderBy('created_at','desc')->get();
        }

        return view('frontend..page.mood_board', $data);
    }

}
